import numpy as np
import pickle
import socket as sk

BOARD_ROWS = 3
BOARD_COLS = 3

class State:
    def __init__(self, p):
        self.board = np.zeros((BOARD_ROWS, BOARD_COLS))
        self.p = p
        self.isEnd = False
        self.boardHash = None
        # init p plays first
        self.playerSymbol = 1

    # get unique hash of current board state
    def getHashClient(self):
        first = "client" if self.playerSymbol == 1 else "server"
        stateHash = (first + str(self.board.reshape(BOARD_ROWS*BOARD_COLS)) +
                     str(self.isEnd))
        stateHash = stateHash.replace("  "," ")
        return stateHash

    def winner(self):
        # row
        for i in range(BOARD_ROWS):
            if sum(self.board[i, :]) == 3:
                self.isEnd = True
                return 1
            if sum(self.board[i, :]) == -3:
                self.isEnd = True
                return -1
        # col
        for i in range(BOARD_COLS):
            if sum(self.board[:, i]) == 3:
                self.isEnd = True
                return 1
            if sum(self.board[:, i]) == -3:
                self.isEnd = True
                return -1
        # diagonal
        diag_sum1 = sum([self.board[i, i] for i in range(BOARD_COLS)])
        diag_sum2 = sum([self.board[i, BOARD_COLS - i - 1] for i in range(BOARD_COLS)])
        diag_sum = max(abs(diag_sum1), abs(diag_sum2))
        if diag_sum == 3:
            self.isEnd = True
            if diag_sum1 == 3 or diag_sum2 == 3:
                return 1
            else:
                return -1
        # tie
        # no available positions
        if len(self.availablePositions()) == 0:
            self.isEnd = True
            return 0
        # not end
        self.isEnd = False
        return None

    def availablePositions(self):
        positions = []
        for i in range(BOARD_ROWS):
            for j in range(BOARD_COLS):
                if self.board[i, j] == 0:
                    positions.append((i, j))  # need to be tuple
        return positions

    def updateState(self, position):
        self.board[position] = self.playerSymbol
        # switch to another player
        self.playerSymbol = -1 if self.playerSymbol == 1 else 1
    
    def setState(self, stateHash):
        self.playerSymbol = 1 if stateHash.startswith("server") else -1
        self.isEnd = True if stateHash.endswith("True") else False
        board_list = stateHash.strip("clientserver[ ]TrueFalse").split(" ")
        self.board = np.asfarray(board_list).reshape((3,3))

    # board reset
    def reset(self):
        self.board = np.zeros((BOARD_ROWS, BOARD_COLS))
        self.boardHash = None
        self.isEnd = False
        self.playerSymbol = 1
                
    def nextMove(self):
        # Player 1
        positions = self.availablePositions()
        p_action = self.p.chooseAction(positions, self.board, self.playerSymbol)
        # take action and upate board state
        self.updateState(p_action)
        # check board status if it is end
        self.winner()
        
class ServerPlayer:
    def __init__(self, name, exp_rate=0.3):
        self.name = name
        self.states = []  # record all positions taken
        self.exp_rate = exp_rate
        self.states_value = {}  # state -> value
        
    def getHash(self, board):
        boardHash = str(board.reshape(BOARD_COLS * BOARD_ROWS))
        return boardHash

    def chooseAction(self, positions, current_board, symbol):
        if np.random.uniform(0, 1) <= self.exp_rate:
            # take random action
            idx = np.random.choice(len(positions))
            action = positions[idx]
        else:
            value_max = -999
            for p in positions:
                next_board = current_board.copy()
                next_board[p] = symbol
                next_boardHash = self.getHash(next_board)
                value = 0 if self.states_value.get(next_boardHash) is None else self.states_value.get(next_boardHash)
                # print("value", value)
                #
                if value >= value_max:
                    value_max = value
                    action = p
        # print("{} takes action {}".format(self.name, action))
        return action
    
    def loadPolicy(self, file):
        fr = open(file, 'rb')
        self.states_value = pickle.load(fr)
        fr.close()

if __name__ == "__main__":
    serverPort = 12000
    serverSocket = sk.socket(sk.AF_INET, sk.SOCK_STREAM)
    serverSocket.bind(('',serverPort))
    serverSocket.listen(1)
    print("Bereit zum Empfangen")
    p = ServerPlayer("new", 0)
    st = State(p)
    print("Bereit zum Spielen")
    while True:
        connectionSocket, addr = serverSocket.accept()
        message = connectionSocket.recv(2048)
        stateHash = message.decode()
        st.setState(stateHash)
        if st.playerSymbol == 1:
            p.loadPolicy("policy_p1")
        else:
            p.loadPolicy("policy_p2")
        win = st.winner()
        if win is None:
            st.nextMove()
        state = st.getHashClient()    
        connectionSocket.send(state.encode())
        connectionSocket.close()
        st.reset()
        