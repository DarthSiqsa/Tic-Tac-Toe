#TCPClient für TicTacToe
import numpy as np
import socket as sk

BOARD_ROWS = 3
BOARD_COLS = 3

class State:
    def __init__(self, clientPlayer):
        self.board = np.zeros((BOARD_ROWS,BOARD_COLS))
        self.player = clientPlayer
        self.isEnd = False
        self.playerSymbol = 1

    def getHashServer(self):
        #  fistPlayer  boardHash                    isEnd
        # e.g. client[ 1. 1. -1. 1. -1. 0. 0. 0. 0.]False
        #      server[ 1. 1. -1. 1. -1. 0. -1. 0. 0.]True
        first = "client" if self.playerSymbol == 1 else "server"
        stateHash = (first + str(self.board.reshape(BOARD_ROWS*BOARD_COLS)) +
                     str(self.isEnd) )
        stateHash = stateHash.replace("  "," ")
        return stateHash

    def winner(self):
        for i in range(BOARD_ROWS):
            if sum(self.board[i, :]) == 3:
                return 1
            if sum(self.board[i, :]) == -3:
                return -1
        for i in range(BOARD_COLS):
            if sum(self.board[:, i]) == 3:
                return 1
            if sum(self.board[:, i]) == -3:
                return -1
        diag_sum1 = sum([self.board[i,i] for i in range(BOARD_COLS)])
        diag_sum2 = sum([self.board[i, BOARD_COLS - i - 1] for i in range(BOARD_COLS)])
        diag_sum = max(abs(diag_sum1),abs(diag_sum2))
        if diag_sum == 3:
            if diag_sum1 == 3 or diag_sum2 == 3:
                return 1
            else:
                return -1
        if len(self.availablePositions()) == 0:
            return 0
        return None

    def availablePositions(self):
        positions = []
        for i in range(BOARD_ROWS):
            for j in range(BOARD_COLS):
                if self.board[i,j] == 0:
                    positions.append((i,j))
        return positions

    def updateState(self, position):
        self.board[position] = self.playerSymbol

    def setState(self, stateHash):
        self.playerSymbol = 1 if stateHash.startswith("client") else -1
        self.isEnd = True if stateHash.endswith("True") else False
        board_list = stateHash.strip("clientserver[ ]TrueFalse").split(" ")
        self.board = np.asfarray(board_list).reshape((3,3))

    def playClient(self):
        positions = self.availablePositions()
        player_action = self.player.chooseAction(positions)
        self.updateState(player_action)

    def printBoard(self):
        board = ''
        for i in range(0,BOARD_ROWS):
            board += '-------------\n'
            out = '| '
            for j in range(0,BOARD_COLS):
                if self.board[i][j] == 1:
                    token = 'x'
                if self.board[i][j] == -1 :
                    token = 'o'
                if self.board[i][j] == 0:
                    token = ' '
                out += token + ' | '
            board += out + '\n'
        board += '-------------'
        print(board)

    def printWinner(self, firstPlayer):
        win = self.winner()
        if win == 0:
            print("Es ist unentschieden.")
        elif (win == 1 and firstPlayer == 's' or
              win == -1 and firstPlayer == 'c'):
            print("Ich habe gewonnen.")
        else:
            print("Gratulation, du hast gewonnen!")


class HumanPlayer:
    def __init__(self, name):
        self.name = name

    def chooseAction(self, positions):
        while True:
            row = input("Geben Sie die Zeile ihres Felds ein! [1/2/3]: ")
            if not row in ['1', '2', '3']: continue
            col = input("Geben Sie die Spalte ihres Felds ein! [1/2/3]: ")
            if not col in ['1', '2', '3']: continue
            action = (int(row) - 1, int(col) - 1)
            if action in positions:
                return action

if __name__ == "__main__":
    serverName = '10.165.180.128'
    serverPort = 12000
    player = HumanPlayer("client")
    st = State(player)
    print("Wir spielen zusammen TicTacToe.")
    question = ""
    while question != "ja" and question != "nein":
        question = input("Willst Du beginnen? [ja/nein]: ")
    if question == "ja":
        st.printBoard()
        st.playClient()
    else:
        st.playerSymbol = -1
    while True:
        message = st.getHashServer()
        clientSocket = sk.socket(sk.AF_INET, sk.SOCK_STREAM)
        clientSocket.connect((serverName, serverPort))
        clientSocket.send(message.encode())
        current_state = clientSocket.recv(2048)
        clientSocket.close()
        st.setState(current_state.decode())
        if st.isEnd:
            st.printBoard()
            st.printWinner(message[0])
            break
        st.printBoard()
        st.playClient()
