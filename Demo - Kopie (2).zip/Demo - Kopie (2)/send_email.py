from email.mime.text import MIMEText
import smtplib

def send_email(email):
    from_email=
    from_password=
    to_email=email

    subject="Tic Tac Toe Contest"
    message= "Thank you for participating in this awesome contest. We love to inform you that you have won the main price: nothing! Congratulations!!!"

    msg=MIMEText(message, 'html')
    msg['Subject']=subject
    msg['To']=to_email
    msg['From']=from_email

    gmail=smtplib.SMTP('smtp.gmail.com',587)
    gmail.ehlo()
    gmail.starttls()
    gmail.login(from_email, from_password)
    gmail.send_message(msg)
