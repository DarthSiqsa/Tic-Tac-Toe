from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy
from send_email import send_email
from sqlalchemy.sql import func

app=Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI']=
db=SQLAlchemy(app)

class Data(db.Model):
    __tablename__="data"
    id=db.Column(db.Integer, primary_key=True)
    email_=db.Column(db.String(120), unique=True)
    first_name_=db.Column(db.String(120))
    last_name_=db.Column(db.String(120))
    gender_=db.Column(db.String(120))
    age_=db.Column(db.Integer)

    def __init__(self, email_, first_name_, last_name_, gender_, age_):
        self.email_=email_
        self.first_name_=first_name_
        self.last_name_=last_name_
        self.gender_=gender_
        self.age_=age_

@app.route("/")
def index():
    return render_template ("index.html")

@app.route("/contest")
def contest():
    return render_template ("contest.html")

@app.route("/success", methods=['POST'])
def success():
    if request.method=='POST':
        email=request.form["email_name"]
        firstname=request.form["first_name"]
        lastname=request.form["last_name"]
        gender=request.form["gender_name"]
        age=request.form["age_name"]
        if db.session.query(Data).filter(Data.email_==email).count() == 0:
            data=Data(email, firstname, lastname, gender, age)
            db.session.add(data)
            db.session.commit()
            send_email(email)
            return render_template("success.html")
        return render_template("index.html", text="Seems like that email already sent us some data. Please enter another email.")

if __name__ == '__main__':
    app.debug=True
    app.run()
